
export default {
    base_url: 'http://luis1.herokuapp.com',
    // base_url:"http://swivli.com",
    update_account: false,

    user_type: '',

    profile_user_name: '',
    user_name: '',
    password: '',
    userCode: '',
    advocate_userid: '',
    signup_id: 0,
    mother: '',

    father: '',
    email: '',
    paarea: '',
    padesc: '',
    paname: '',
    phone: '',
    paorg: '',

    edit_case_json: null,
    visitStatus: '',
    editcase_page_title: 'Visit Master',
    procedure_selected_top_tab: 'Procedure',

    icd_admin_json: null,
    icd_admin_page_title: "Icd Master",

    lab_admin_json: null,

    symptom_admin_json: null,

    cpt_admin_json: null,
    cpt_admin_page_title: "CptMaster",

}